<?php
// Senast uppdaterad: 2026-10-13 11:00 (Asia/Bangkok) | Version 1.00 | av: KlⒶssⓔ & Ⓐberg
/**
 * Skicka godkända bilduppladdningar utan direkt åtkomst till storage/.
 * Version 1.00 | Senast uppdaterad: 2026-10-13 11:00 (Asia/Bangkok)
 */
declare(strict_types=1);
require_once __DIR__ . '/app/bootstrap.php';
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id || $id < 1) { http_response_code(404); exit; }
$stmt = db()->prepare('SELECT filename, mime FROM photos WHERE id = ?');
$stmt->execute([$id]);
$photo = $stmt->fetch();
if (!$photo || !preg_match('/\A[a-f0-9]{32}\.(jpg|png|webp)\z/', $photo['filename'])) { http_response_code(404); exit; }
$path = STORAGE_DIR . '/photos/' . $photo['filename'];
if (!is_file($path)) { http_response_code(404); exit; }
if (!in_array($photo['mime'], ['image/jpeg','image/png','image/webp'], true)) { http_response_code(404); exit; }
header('Content-Type: ' . $photo['mime']);
header('Content-Length: ' . (string)filesize($path));
header('Content-Disposition: inline; filename="market-photo.' . image_extension($photo['mime']) . '"');
header('Cache-Control: private, max-age=86400');
header('X-Content-Type-Options: nosniff');
readfile($path);

<?php
// Senast uppdaterad: 2026-10-13 11:00 (Asia/Bangkok) | Version 1.00 | av: KlⒶssⓔ & Ⓐberg
// Chiang Mai Market Journal – serverinställningar.
// Installationsnyckeln behövs ENDAST för att skapa första adminkontot.
// Byt gärna nyckeln innan du publicerar om ZIP-filen delas med andra.
declare(strict_types=1);

const SITE_TITLE = 'Chiang Mai Market Journal';
const SETUP_KEY = 'm27Ww1XHWQpyYhaLYPn9NyPz0C_2_bPH';
const MAX_PHOTO_BYTES = 5 * 1024 * 1024; // 5 MB per bild.
const MAX_PHOTOS_PER_REVIEW = 8;
const MAX_BACKUP_BYTES = 80 * 1024 * 1024; // Max 80 MB komprimerad ZIP vid import.
const STORAGE_DIR = __DIR__ . '/../storage';

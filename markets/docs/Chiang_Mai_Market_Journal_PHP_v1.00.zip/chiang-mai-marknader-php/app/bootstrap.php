<?php
// Senast uppdaterad: 2026-10-13 11:00 (Asia/Bangkok) | Version 1.00 | av: KlⒶssⓔ & Ⓐberg
/** Gemensam uppstart: session, databas, formulärskydd och HTML-hjälpare. */
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/markets.php';

// Besök och visning av datum utgår från lokal tid i Chiang Mai.
date_default_timezone_set('Asia/Bangkok');

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_name('cm_market_journal');
    session_set_cookie_params([
        'httponly' => true,
        'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
        'samesite' => 'Lax',
        'path' => '/',
    ]);
    session_start();
}
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('X-Frame-Options: SAMEORIGIN');

function h(?string $value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function app_url(string $path = 'index.php', array $query = []): string
{
    // Baserar länkar på projektets faktiska sökväg – fungerar även i undermapp.
    $base = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/index.php')), '/');
    $url = ($base === '' ? '' : $base) . '/' . ltrim($path, '/');
    if ($query) $url .= '?' . http_build_query($query, '', '&', PHP_QUERY_RFC3986);
    return $url;
}

function go(string $path = 'index.php', array $query = []): never
{
    header('Location: ' . app_url($path, $query), true, 303);
    exit;
}

function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    if (!extension_loaded('pdo_sqlite')) {
        throw new RuntimeException('PHP-tillägget pdo_sqlite saknas. Aktivera/installera php-sqlite3 på servern.');
    }
    if (!is_dir(STORAGE_DIR) && !mkdir(STORAGE_DIR, 0700, true) && !is_dir(STORAGE_DIR)) {
        throw new RuntimeException('Kunde inte skapa lagringsmappen storage/.');
    }
    foreach ([STORAGE_DIR . '/photos', STORAGE_DIR . '/tmp'] as $dir) {
        if (!is_dir($dir) && !mkdir($dir, 0700, true) && !is_dir($dir)) {
            throw new RuntimeException('Kunde inte skapa lagringsmappen: ' . basename($dir));
        }
    }
    try {
        $pdo = new PDO('sqlite:' . STORAGE_DIR . '/market_journal.sqlite');
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $pdo->exec('PRAGMA foreign_keys=ON');
        $pdo->exec('PRAGMA busy_timeout=5000');
        $pdo->exec('CREATE TABLE IF NOT EXISTS admins (id INTEGER PRIMARY KEY, username TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL, created_at TEXT NOT NULL)');
        $pdo->exec('CREATE TABLE IF NOT EXISTS reviews (id INTEGER PRIMARY KEY AUTOINCREMENT, market_slug TEXT NOT NULL, title TEXT NOT NULL, body TEXT NOT NULL, rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5), visited_on TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)');
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_reviews_market ON reviews(market_slug, created_at DESC)');
        $pdo->exec('CREATE TABLE IF NOT EXISTS photos (id INTEGER PRIMARY KEY AUTOINCREMENT, review_id INTEGER NOT NULL REFERENCES reviews(id) ON DELETE CASCADE, filename TEXT NOT NULL UNIQUE, mime TEXT NOT NULL, created_at TEXT NOT NULL)');
        return $pdo;
    } catch (PDOException $e) {
        throw new RuntimeException('Databasen kunde inte öppnas. Kontrollera skrivbehörigheten på storage/ och att pdo_sqlite är aktiverat.', 0, $e);
    }
}

function is_installed(): bool
{
    // Tillåt att startsidan visar felsökningsmeddelande om SQLite saknas.
    try { return (bool)db()->query('SELECT COUNT(*) FROM admins')->fetchColumn(); }
    catch (Throwable $e) { return false; }
}

function is_admin(): bool
{
    return is_installed() && !empty($_SESSION['admin_id']);
}

function require_admin(): void
{
    if (!is_admin()) go('admin.php');
}

function csrf_token(): string
{
    if (!isset($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}

function csrf_check(): void
{
    if (!hash_equals(csrf_token(), (string)($_POST['csrf'] ?? ''))) {
        http_response_code(403);
        exit('Formuläret har gått ut. Ladda om sidan och försök igen.');
    }
}

function flash(string $type, string $message): void
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function take_flash(): ?array
{
    $value = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $value;
}

function date_se(string $value): string
{
    $t = strtotime($value);
    return $t === false ? $value : date('j M Y', $t);
}

function mb_safe_lower(string $text): string
{
    return function_exists('mb_strtolower') ? mb_strtolower($text, 'UTF-8') : strtolower(str_replace(['Å','Ä','Ö'], ['å','ä','ö'], $text));
}

function stars(int $value): string
{
    return str_repeat('★', max(0, min(5, $value))) . str_repeat('☆', max(0, 5 - $value));
}

function validate_photo(string $tmp, int $size): string
{
    if ($size < 1 || $size > MAX_PHOTO_BYTES) {
        throw new RuntimeException('En bild måste vara högst 5 MB och får inte vara tom.');
    }
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($tmp);
    $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    if (!isset($allowed[$mime])) {
        throw new RuntimeException('Bara JPG, PNG och WebP är tillåtna som bilder.');
    }
    $dimensions = @getimagesize($tmp);
    if (!$dimensions || ($dimensions['mime'] ?? '') !== $mime || $dimensions[0] > 10000 || $dimensions[1] > 10000 || ($dimensions[0] * $dimensions[1]) > 30000000) {
        throw new RuntimeException('Ogiltig bild eller för stora bilddimensioner.');
    }
    return $mime;
}

function image_extension(string $mime): string
{
    return ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'][$mime] ?? 'bin';
}

function store_uploaded_photo(string $tmp, string $mime): string
{
    $filename = bin2hex(random_bytes(16)) . '.' . image_extension($mime);
    $dest = STORAGE_DIR . '/photos/' . $filename;
    if (!move_uploaded_file($tmp, $dest)) throw new RuntimeException('Kunde inte spara bilden på servern.');
    @chmod($dest, 0600);
    return $filename;
}

function view(string $file, array $data = []): void
{
    extract($data, EXTR_SKIP);
    require __DIR__ . '/views/' . $file;
}

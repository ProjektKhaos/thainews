</main>
<footer class="site-footer">
  <div class="shell footer-grid">
    <div><strong>CHIANG MAI MARKET JOURNAL</strong><p>En personlig marknadsguide – byggd för minnen, fynd och nya favoriter.</p></div>
    <div class="footer-aside">Öppettiderna är ungefärliga och kan ändras.<br>Skapad med PHP + SQLite · v1.00</div>
  </div>
</footer>
</body>
</html>

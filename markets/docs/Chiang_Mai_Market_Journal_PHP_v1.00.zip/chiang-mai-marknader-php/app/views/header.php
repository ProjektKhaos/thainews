<?php
// Senast uppdaterad: 2026-10-13 11:00 (Asia/Bangkok) | Version 1.00 | av: KlⒶssⓔ & Ⓐberg
/** @var string $title */
$displayTitle = $title ?? 'Marknader i Chiang Mai';
?>
<!doctype html>
<html lang="sv">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#183f39">
  <meta name="description" content="Upptäck marknaderna i Chiang Mai och dokumentera egna besök med recensioner, stjärnor och bilder.">
  <title><?= h($displayTitle) ?> · Chiang Mai Market Journal</title>
  <link rel="stylesheet" href="<?= h(app_url('assets/style.css')) ?>?v=1.00">
  <script src="<?= h(app_url('assets/app.js')) ?>?v=1.00" defer></script>
</head>
<body>
<a class="skip-link" href="#main">Hoppa till innehållet</a>
<header class="site-header">
  <div class="shell nav-bar">
    <a class="brand" href="<?= h(app_url()) ?>" aria-label="Till alla marknader">
      <span class="brand-mark">CM<span>✳</span></span>
      <span class="brand-wordmark">CHIANG MAI <small>MARKET JOURNAL</small></span>
    </a>
    <nav class="nav-links" aria-label="Huvudmeny">
      <a href="<?= h(app_url()) ?>">Alla marknader</a>
      <?php if (is_admin()): ?>
        <a class="nav-pill" href="<?= h(app_url('admin.php')) ?>">⚙ Admin</a>
      <?php else: ?>
        <a class="nav-pill" href="<?= h(app_url('admin.php')) ?>">Logga in</a>
      <?php endif; ?>
    </nav>
  </div>
</header>
<?php if ($flash = take_flash()): ?>
  <div class="shell"><div class="notice <?= $flash['type'] === 'success' ? 'success' : 'error' ?>" role="status"><?= h($flash['message']) ?></div></div>
<?php endif; ?>
<main id="main">

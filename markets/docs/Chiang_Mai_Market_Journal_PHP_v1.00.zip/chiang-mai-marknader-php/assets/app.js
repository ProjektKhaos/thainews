/**
 * Chiang Mai Market Journal | Version 1.00
 * Senast uppdaterad: 2026-10-13 11:00 | KlⒶssⓔ & Ⓐberg
 * Lättviktig vanilla JavaScript. Alla sidor fungerar även utan JS.
 */
(() => {
  'use strict';

  const search = document.getElementById('market-search');
  const cards = [...document.querySelectorAll('.market-card')];
  const filters = [...document.querySelectorAll('[data-filter]')];
  const counter = document.getElementById('market-count');
  const empty = document.getElementById('filter-empty');
  let selectedFilter = 'Alla';

  // Sök ord för ord så "billig mat" inte behöver stå i exakt följd.
  const normalize = (s) => String(s || '').toLocaleLowerCase('sv-SE').trim();
  const update = () => {
    if (!search || !cards.length) return;
    const words = normalize(search.value).split(/\s+/).filter(Boolean);
    let shown = 0;
    for (const card of cards) {
      const matchesCategory = selectedFilter === 'Alla' || card.dataset.category === selectedFilter;
      const searchable = normalize(card.dataset.search);
      const matchesWords = words.every(word => searchable.includes(word));
      const visible = matchesCategory && matchesWords;
      card.hidden = !visible;
      if (visible) shown++;
    }
    if (counter) counter.textContent = `${shown} ${shown === 1 ? 'marknad' : 'marknader'}`;
    if (empty) empty.hidden = shown > 0;
  };
  if (search) search.addEventListener('input', update);
  for (const filter of filters) filter.addEventListener('click', () => {
    selectedFilter = filter.dataset.filter;
    for (const button of filters) {
      button.classList.toggle('selected', button === filter);
      button.setAttribute('aria-pressed', String(button === filter));
    }
    update();
  });

  // Små förhandsvisningar innan bilder laddas upp (ändrar inte filerna).
  const fileInput = document.querySelector('[data-photo-input]');
  const preview = document.getElementById('upload-preview');
  let objectUrls = [];
  if (fileInput && preview) fileInput.addEventListener('change', () => {
    objectUrls.forEach(URL.revokeObjectURL);
    objectUrls = [];
    preview.replaceChildren();
    const files = [...fileInput.files];
    if (files.length > 8) {
      const p = document.createElement('p');
      p.className = 'upload-warning';
      p.textContent = 'Högst 8 bilder per recension, inklusive tidigare sparade bilder.';
      preview.append(p);
    }
    for (const file of files.slice(0, 8)) {
      const figure = document.createElement('figure');
      const img = document.createElement('img');
      const figcaption = document.createElement('figcaption');
      const url = URL.createObjectURL(file);
      objectUrls.push(url);
      img.src = url;
      img.alt = 'Förhandsvisning av ' + file.name;
      figcaption.textContent = file.name;
      figure.append(img, figcaption);
      preview.append(figure);
    }
  });
})();

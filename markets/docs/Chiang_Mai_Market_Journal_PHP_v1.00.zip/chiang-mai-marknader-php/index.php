<?php
// Senast uppdaterad: 2026-10-13 11:00 (Asia/Bangkok) | Version 1.00 | av: KlⒶssⓔ & Ⓐberg
/**
 * Index / marknadsdetalj – Version 1.00
 * Senast uppdaterad: 2026-10-13 11:00 (Asia/Bangkok) | KlⒶssⓔ & Ⓐberg
 */
declare(strict_types=1);
require_once __DIR__ . '/app/bootstrap.php';

try {
    $pdo = db();
} catch (Throwable $e) {
    http_response_code(503);
    view('header.php', ['title' => 'Installation behövs']);
    echo '<section class="shell narrow empty-state"><h1>Servern behöver en liten inställning</h1><p>' . h($e->getMessage()) . '</p><p>Se README.md för hjälp med PHP SQLite och lagringsrättigheter.</p></section>';
    view('footer.php');
    exit;
}

$slug = trim((string)($_GET['m'] ?? ''));
$market = $slug === '' ? null : market_by_slug($slug);
if ($slug !== '' && !$market) {
    http_response_code(404);
    view('header.php', ['title' => 'Marknaden hittades inte']);
    echo '<section class="shell narrow empty-state"><h1>Den marknaden finns inte</h1><p><a class="btn" href="' . h(app_url()) . '">← Visa marknaderna</a></p></section>';
    view('footer.php');
    exit;
}

if (!$market) {
    $markets = market_catalog();
    $statsRows = $pdo->query('SELECT market_slug, COUNT(*) AS amount, AVG(rating) AS avg_rating FROM reviews GROUP BY market_slug')->fetchAll();
    $stats = [];
    foreach ($statsRows as $r) $stats[$r['market_slug']] = $r;
    $totalReviews = (int)$pdo->query('SELECT COUNT(*) FROM reviews')->fetchColumn();
    $totalPhotos = (int)$pdo->query('SELECT COUNT(*) FROM photos')->fetchColumn();
    view('header.php', ['title'=>'Alla marknader']);
    ?>
    <section class="hero">
      <div class="shell hero-inner">
        <div class="hero-topline"><span class="hero-line"></span> EN PERSONLIG GUIDE TILL NORRA THAILAND <span class="hero-line"></span></div>
        <div class="hero-content">
          <div>
            <span class="eyebrow">MARKNADER · MAT · MÄNNISKOR</span>
            <h1>Chiang Mai,<br><em>marknad för marknad.</em></h1>
            <p class="hero-lead">Från morgonens färskvaror till nattens neonljus. Här samlar du dina favoriter, egna recensioner och bilder – allt på ett ställe.</p>
            <a class="btn btn-light" href="#market-list">Utforska marknaderna <span aria-hidden="true">↘</span></a>
          </div>
          <div class="hero-art" aria-hidden="true">
            <div class="art-circle circle-one"></div><div class="art-circle circle-two"></div>
            <div class="art-poster"><span class="thai-glyph">ตลาด</span><span class="poster-title">STREETS<br>& STORIES</span><span class="poster-mini">18.7883° N / 98.9853° E</span></div>
            <div class="art-badge">DISCOVER<br>LOCAL<br>PLACES <span>✳</span></div>
          </div>
        </div>
        <div class="hero-stats">
          <div><strong><?= count($markets) ?></strong><span>marknader i guiden</span></div>
          <div><strong><?= $totalReviews ?></strong><span>egna recensioner</span></div>
          <div><strong><?= $totalPhotos ?></strong><span>uppladdade bilder</span></div>
          <div class="hero-location">📍 CHIANG MAI · THAILAND</div>
        </div>
      </div>
    </section>
    <section class="shell catalog-section" id="market-list">
      <div class="section-kicker"><span class="round-star">✳</span> DIN GUIDE</div>
      <div class="section-head"><div><h2>Hitta din nästa <em>favorit.</em></h2><p>Filtrera efter typ eller sök på namn, område och vad marknaden erbjuder.</p></div><span class="result-counter" id="market-count"><?= count($markets) ?> marknader</span></div>
      <div class="filters">
        <label class="search-wrap"><span aria-hidden="true">⌕</span><input id="market-search" type="search" placeholder="Sök marknad, mat, kläder, loppis…" aria-label="Sök bland marknader" autocomplete="off"></label>
        <div class="filter-pills" aria-label="Filtrera efter marknadstyp">
          <?php foreach (['Alla', 'Dagmarknad', 'Nattmarknad', 'Helgmarknad', 'Kvartersmarknad', 'Specialmarknad'] as $i => $category): ?>
            <button type="button" class="filter-btn <?= $i === 0 ? 'selected' : '' ?>" data-filter="<?= h($category) ?>" aria-pressed="<?= $i === 0 ? 'true' : 'false' ?>"><?= h($category) ?></button>
          <?php endforeach; ?>
        </div>
      </div>
      <div class="market-grid" id="market-grid">
        <?php foreach ($markets as $index => $m):
          $count = (int)($stats[$m['slug']]['amount'] ?? 0);
          $average = isset($stats[$m['slug']]) ? number_format((float)$stats[$m['slug']]['avg_rating'], 1, ',', '') : null;
        ?>
          <a class="market-card" href="<?= h(app_url('index.php', ['m'=>$m['slug']])) ?>" data-category="<?= h($m['category']) ?>" data-search="<?= h(mb_safe_lower(implode(' ', [$m['name'], $m['area'], $m['category'], implode(' ', $m['tags']), $m['description']]))) ?>">
            <div class="card-art art-tone-<?= $index % 6 ?>"><div class="art-symbol"><?= h($m['icon']) ?></div><div class="art-large-num"><?= str_pad((string)($index + 1), 2, '0', STR_PAD_LEFT) ?></div><span class="art-category"><?= h($m['category']) ?></span></div>
            <div class="card-content"><div class="card-meta"><span>📍 <?= h($m['area']) ?></span><?php if ($average !== null): ?><span class="rating-mini">★ <?= h($average) ?></span><?php endif; ?></div><h3><?= h($m['name']) ?></h3><p><?= h($m['description']) ?></p><div class="card-footer"><span><?= $count ?> <?= $count === 1 ? 'recension' : 'recensioner' ?></span><span class="card-arrow">↗</span></div></div>
          </a>
        <?php endforeach; ?>
      </div>
      <div id="filter-empty" class="no-results" hidden>Inga marknader matchade sökningen. Prova ett annat ord eller filter.</div>
    </section>
    <?php
    view('footer.php');
    exit;
}

// Individuell marknad: samla recensioner och deras bilder.
$stmt = $pdo->prepare('SELECT * FROM reviews WHERE market_slug = ? ORDER BY created_at DESC, id DESC');
$stmt->execute([$slug]);
$reviews = $stmt->fetchAll();
$reviewIds = array_column($reviews, 'id');
$photosByReview = [];
if ($reviewIds) {
    $placeholders = implode(',', array_fill(0, count($reviewIds), '?'));
    $photoStmt = $pdo->prepare('SELECT * FROM photos WHERE review_id IN (' . $placeholders . ') ORDER BY id DESC');
    $photoStmt->execute($reviewIds);
    foreach ($photoStmt->fetchAll() as $p) $photosByReview[(int)$p['review_id']][] = $p;
}
$average = $reviews ? array_sum(array_map(static fn($r) => (int)$r['rating'], $reviews)) / count($reviews) : null;
$editing = null;
if (is_admin() && isset($_GET['edit'])) {
    foreach ($reviews as $r) if ((int)$r['id'] === (int)$_GET['edit']) $editing = $r;
}
$mapQuery = $market['name'] . ', Chiang Mai, Thailand';
view('header.php', ['title'=>$market['name']]);
?>
<section class="detail-banner">
  <div class="shell">
    <div class="breadcrumbs"><a href="<?= h(app_url()) ?>">← Alla marknader</a><span>/</span><span><?= h($market['category']) ?></span></div>
    <div class="detail-hero-grid"><div>
      <span class="eyebrow light-eyebrow">📍 <?= h($market['area']) ?> · <?= h($market['category']) ?></span>
      <h1><?= h($market['name']) ?></h1>
      <p><?= h($market['description']) ?></p>
      <div class="detail-actions"><a class="btn btn-light" href="https://www.google.com/maps/search/?api=1&amp;query=<?= rawurlencode($mapQuery) ?>" target="_blank" rel="noopener noreferrer">📍 Visa på Google Maps ↗</a><span class="detail-hours">◷ <?= h($market['schedule']) ?></span></div>
    </div><div class="detail-emblem" aria-hidden="true"><?= h($market['icon']) ?><small>CHIANG MAI MARKET JOURNAL</small></div></div>
  </div>
</section>
<section class="shell detail-section">
  <div class="tag-row"><?php foreach ($market['tags'] as $tag): ?><span class="tag"><?= h($tag) ?></span><?php endforeach; ?></div>
  <div class="review-head"><div><div class="section-kicker">✳ DIN PERSONLIGA DAGBOK</div><h2>Besök & <em>recensioner</em></h2><p>Samla intryck, betyg och fotografier från varje besök.</p></div><div class="overall-score"><?php if ($average !== null): ?><strong><?= number_format($average, 1, ',', '') ?><small>/5</small></strong><span>★ <?= count($reviews) ?> <?= count($reviews) === 1 ? 'recension' : 'recensioner' ?></span><?php else: ?><strong>—</strong><span>Inga betyg ännu</span><?php endif; ?></div></div>
  <?php if (is_admin()): ?>
    <div class="editor-panel" id="skriv-recension">
      <div class="editor-top"><div><span class="eyebrow">DINA ANTECKNINGAR</span><h3><?= $editing ? 'Redigera besöket' : 'Skriv om ett besök' ?></h3></div><span class="editor-icon">✎</span></div>
      <form action="<?= h(app_url('action.php')) ?>" method="post" enctype="multipart/form-data" class="review-form">
        <input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>">
        <input type="hidden" name="action" value="save_review">
        <input type="hidden" name="market_slug" value="<?= h($slug) ?>">
        <input type="hidden" name="review_id" value="<?= $editing ? (int)$editing['id'] : 0 ?>">
        <div class="form-two-col"><label>Titel på besöket <input type="text" name="title" maxlength="120" required placeholder="Exempel: Fantastisk street food!" value="<?= h($editing['title'] ?? '') ?>"></label><label>Besöksdatum <input type="date" name="visited_on" max="<?= date('Y-m-d') ?>" value="<?= h($editing['visited_on'] ?? date('Y-m-d')) ?>"></label></div>
        <div class="rating-field"><span>Mitt betyg</span><div class="star-picker" role="radiogroup" aria-label="Välj betyg mellan 1 och 5">
            <?php for ($i = 5; $i >= 1; $i--): ?><input type="radio" id="star<?= $i ?>" name="rating" value="<?= $i ?>" <?= (int)($editing['rating'] ?? 5) === $i ? 'checked' : '' ?> required><label for="star<?= $i ?>" title="<?= $i ?> av 5 stjärnor">★</label><?php endfor; ?>
        </div></div>
        <label>Din recension <textarea name="body" rows="6" maxlength="5000" required placeholder="Vad såg du? Vad åt du? Var det prisvärt? Vilka fynd gjorde du? Skriv precis som du vill."><?= h($editing['body'] ?? '') ?></textarea></label>
        <label class="upload-box"><span class="upload-symbol">＋</span><strong>Lägg till bilder från besöket</strong><small>Välj flera JPG, PNG eller WebP · högst 5 MB per bild · max <?= MAX_PHOTOS_PER_REVIEW ?> bilder per recension</small><input type="file" name="photos[]" accept="image/jpeg,image/png,image/webp" multiple data-photo-input></label>
        <div class="preview-grid" id="upload-preview" aria-live="polite"></div>
        <div class="form-bottom"><button class="btn btn-primary" type="submit"><?= $editing ? 'Spara ändringar' : 'Publicera min recension' ?> ↗</button><?php if ($editing): ?><a href="<?= h(app_url('index.php', ['m'=>$slug])) ?>#skriv-recension" class="text-link">Avbryt redigering</a><?php endif; ?></div>
      </form>
    </div>
  <?php elseif (!is_installed()): ?>
    <div class="soft-callout">Första besöket här? <a href="<?= h(app_url('admin.php')) ?>">Skapa ditt adminkonto</a> för att lägga till recensioner och bilder.</div>
  <?php endif; ?>
  <?php if (!$reviews): ?><div class="review-empty"><span>✧</span><h3>Här börjar dina marknadsminnen</h3><p>Inga recensioner ännu. <?= is_admin() ? 'Skriv den första ovan och lägg gärna till ett par bilder!' : 'Här kommer egna besök, bilder och betyg att visas.' ?></p></div><?php endif; ?>
  <div class="review-list">
    <?php foreach ($reviews as $r): $photos = $photosByReview[(int)$r['id']] ?? []; ?>
      <article class="review-card" id="review-<?= (int)$r['id'] ?>">
        <div class="review-card-top"><div class="review-date"><span class="review-avatar">Å</span><div><strong>Marknadsdagboken</strong><small><?= h($r['visited_on'] ? date_se($r['visited_on']) : date_se($r['created_at'])) ?></small></div></div><span class="review-stars" aria-label="<?= (int)$r['rating'] ?> av 5 stjärnor"><?= stars((int)$r['rating']) ?></span></div>
        <h3><?= h($r['title']) ?></h3><div class="review-copy"><?= nl2br(h($r['body'])) ?></div>
        <?php if ($photos): ?><div class="photo-grid"><?php foreach ($photos as $p): ?><div class="photo-tile"><a href="<?= h(app_url('photo.php', ['id'=>(int)$p['id']])) ?>" target="_blank" rel="noopener"><img src="<?= h(app_url('photo.php', ['id'=>(int)$p['id']])) ?>" loading="lazy" alt="Foto från <?= h($market['name']) ?>"></a><?php if (is_admin()): ?><form method="post" action="<?= h(app_url('action.php')) ?>" onsubmit="return confirm('Ta bort den här bilden?')"><input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>"><input type="hidden" name="action" value="delete_photo"><input type="hidden" name="market_slug" value="<?= h($slug) ?>"><input type="hidden" name="photo_id" value="<?= (int)$p['id'] ?>"><button type="submit" title="Ta bort bilden" aria-label="Ta bort bilden">×</button></form><?php endif; ?></div><?php endforeach; ?></div><?php endif; ?>
        <?php if (is_admin()): ?><div class="review-tools"><a href="<?= h(app_url('index.php', ['m'=>$slug,'edit'=>(int)$r['id']])) ?>#skriv-recension">✎ Redigera</a><form action="<?= h(app_url('action.php')) ?>" method="post" onsubmit="return confirm('Vill du radera hela recensionen och alla dess bilder?')"><input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>"><input type="hidden" name="action" value="delete_review"><input type="hidden" name="market_slug" value="<?= h($slug) ?>"><input type="hidden" name="review_id" value="<?= (int)$r['id'] ?>"><button type="submit" class="delete-action">Radera</button></form></div><?php endif; ?>
      </article>
    <?php endforeach; ?>
  </div>
  <a class="bottom-back" href="<?= h(app_url()) ?>">← Tillbaka till alla marknader</a>
</section>
<?php view('footer.php'); ?>

# Ändringshistorik

## 1.00 – 2026-10-13
- 34 marknader inom Chiang Mai City/omnejd.
- Startsidans sökning, kategorifilter och marknadskort.
- Marknadssidor med Google Maps, beskrivningar och öppettider.
- Flera recensionsinlägg per marknad, med 1–5 stjärnor och besöksdatum.
- Uppladdning, visning och radering av upp till 8 bilder per recension.
- PHP + PDO/SQLite, första admininstallation, inloggning och lösenordsbyte.
- ZIP-export/återställning av bilder och recensioner.
- Mobilanpassad design, säkra formulär och skyddad lagring för Apache.

<?php
// Senast uppdaterad: 2026-10-13 11:00 (Asia/Bangkok) | Version 1.00 | av: KlⒶssⓔ & Ⓐberg
/**
 * ZIP-export och återställning för recensioner och originalbilder.
 * Version 1.00 | Senast uppdaterad: 2026-10-13 11:00 (Asia/Bangkok)
 * Kräver PHP-tillägget zip. Adminsession och CSRF-skydd krävs.
 */
declare(strict_types=1);
require_once __DIR__ . '/app/bootstrap.php';
require_admin();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit('Endast POST tillåtet.'); }
csrf_check();
if (!class_exists('ZipArchive')) { flash('error', 'PHP-tillägget zip saknas.'); go('admin.php'); }
$pdo = db();
$action = (string)($_POST['action'] ?? '');

try {
    if ($action === 'export') {
        $tmpZip = tempnam(STORAGE_DIR . '/tmp', 'cm-export-');
        if ($tmpZip === false) throw new RuntimeException('Kunde inte skapa temporär backupfil.');
        $zip = new ZipArchive();
        if ($zip->open($tmpZip, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            @unlink($tmpZip);
            throw new RuntimeException('Kunde inte skapa ZIP-arkivet.');
        }
        $reviews = $pdo->query('SELECT id, market_slug, title, body, rating, visited_on, created_at, updated_at FROM reviews ORDER BY id')->fetchAll();
        $photoRows = $pdo->query('SELECT id, review_id, filename, mime, created_at FROM photos ORDER BY id')->fetchAll();
        $photos = [];
        foreach ($photoRows as $photo) {
            $path = STORAGE_DIR . '/photos/' . $photo['filename'];
            if (is_file($path)) {
                $zip->addFile($path, 'photos/' . $photo['filename']);
                $photos[] = $photo;
            }
        }
        $manifest = ['format'=>'chiang-mai-market-journal', 'version'=>1, 'exported_at'=>gmdate('c'), 'reviews'=>$reviews, 'photos'=>$photos];
        $zip->addFromString('manifest.json', json_encode($manifest, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR));
        if (!$zip->close()) { @unlink($tmpZip); throw new RuntimeException('ZIP-arkivet kunde inte färdigställas.'); }
        $name = 'chiang-mai-market-backup-' . date('Y-m-d-His') . '.zip';
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . $name . '"');
        header('Content-Length: ' . filesize($tmpZip));
        header('Cache-Control: no-store');
        readfile($tmpZip);
        @unlink($tmpZip);
        exit;
    }
    if ($action !== 'import') throw new RuntimeException('Okänd backupåtgärd.');
    if (($_POST['confirm_replace'] ?? '') !== 'yes') throw new RuntimeException('Bekräfta att nuvarande innehåll får ersättas.');
    if (!isset($_FILES['backup_file']) || $_FILES['backup_file']['error'] !== UPLOAD_ERR_OK) throw new RuntimeException('Välj en giltig ZIP-backup att återställa.');
    $upload = $_FILES['backup_file'];
    if ($upload['size'] < 1 || $upload['size'] > MAX_BACKUP_BYTES) throw new RuntimeException('ZIP-filen får vara högst 80 MB.');
    if (!is_uploaded_file($upload['tmp_name'])) throw new RuntimeException('Uppladdningen är ogiltig.');
    $zip = new ZipArchive();
    if ($zip->open($upload['tmp_name'], ZipArchive::RDONLY) !== true) throw new RuntimeException('Filen är inte ett läsbart ZIP-arkiv.');
    try {
        if ($zip->numFiles > 5001) throw new RuntimeException('Backupen innehåller för många filer.');
        $manifestIndex = $zip->locateName('manifest.json');
        $meta = $manifestIndex === false ? false : $zip->statIndex($manifestIndex);
        if (!$meta || ($meta['size'] ?? 0) > 4 * 1024 * 1024) throw new RuntimeException('ZIP-filen saknar en giltig manifest.json.');
        $json = $zip->getFromName('manifest.json');
        if ($json === false) throw new RuntimeException('Kunde inte läsa manifest.json.');
        $manifest = json_decode($json, true, 512, JSON_THROW_ON_ERROR);
        if (($manifest['format'] ?? '') !== 'chiang-mai-market-journal' || ($manifest['version'] ?? null) !== 1 || !is_array($manifest['reviews'] ?? null) || !is_array($manifest['photos'] ?? null)) {
            throw new RuntimeException('Detta är inte en kompatibel Market Journal-backup.');
        }
        if (count($manifest['reviews']) > 2000 || count($manifest['photos']) > 5000) throw new RuntimeException('Backupen innehåller för många poster.');
        // Kontrollera poster innan databasens nuvarande innehåll påverkas.
        $reviewIds = [];
        foreach ($manifest['reviews'] as $r) {
            if (!is_array($r) || !isset($r['id']) || !is_numeric($r['id']) || !market_by_slug((string)($r['market_slug'] ?? '')) || !is_string($r['title'] ?? null) || !is_string($r['body'] ?? null) || trim($r['title']) === '' || trim($r['body']) === '' || strlen($r['title']) > 400 || strlen($r['body']) > 20000 || !is_numeric($r['rating'] ?? null) || (int)$r['rating'] < 1 || (int)$r['rating'] > 5) {
                throw new RuntimeException('Backupen har en ogiltig recension.');
            }
            $oldId = (int)$r['id'];
            if ($oldId < 1 || isset($reviewIds[$oldId])) throw new RuntimeException('Backupen har dubbla eller felaktiga recensions-ID.');
            $reviewIds[$oldId] = true;
        }
        $preparedPhotos = [];
        $newFiles = [];
        $totalUncompressed = 0;
        try {
            foreach ($manifest['photos'] as $p) {
                if (!is_array($p) || !isset($reviewIds[(int)($p['review_id'] ?? 0)]) || !is_string($p['filename'] ?? null) || !preg_match('/\A[a-f0-9]{32}\.(jpg|png|webp)\z/', $p['filename'])) {
                    throw new RuntimeException('Backupen har en ogiltig bildreferens.');
                }
                $entry = 'photos/' . $p['filename'];
                $entryStat = $zip->statName($entry);
                if (!$entryStat || ($entryStat['size'] ?? 0) > MAX_PHOTO_BYTES || ($entryStat['size'] ?? 0) < 1) throw new RuntimeException('En backupbild saknas eller är för stor.');
                $totalUncompressed += (int)$entryStat['size'];
                if ($totalUncompressed > 250 * 1024 * 1024) throw new RuntimeException('Backupen innehåller mer än 250 MB bilder uppackade.');
                $bytes = $zip->getFromName($entry);
                if ($bytes === false) throw new RuntimeException('Kunde inte läsa en bild i backupen.');
                $temp = tempnam(STORAGE_DIR . '/tmp', 'cm-restore-');
                if ($temp === false || file_put_contents($temp, $bytes) === false) throw new RuntimeException('Kunde inte förbereda bildåterställningen.');
                try { $mime = validate_photo($temp, strlen($bytes)); }
                finally { @unlink($temp); }
                if ($mime !== ($p['mime'] ?? null)) throw new RuntimeException('En bild har fel MIME-typ i backupen.');
                $newName = bin2hex(random_bytes(16)) . '.' . image_extension($mime);
                if (file_put_contents(STORAGE_DIR . '/photos/' . $newName, $bytes, LOCK_EX) === false) throw new RuntimeException('Kunde inte återställa en bild.');
                @chmod(STORAGE_DIR . '/photos/' . $newName, 0600);
                $newFiles[] = $newName;
                $preparedPhotos[] = ['review_id'=>(int)$p['review_id'], 'filename'=>$newName, 'mime'=>$mime, 'created_at'=>(string)($p['created_at'] ?? gmdate('c'))];
            }
            $oldFiles = $pdo->query('SELECT filename FROM photos')->fetchAll(PDO::FETCH_COLUMN);
            $pdo->beginTransaction();
            try {
                $pdo->exec('DELETE FROM photos');
                $pdo->exec('DELETE FROM reviews');
                $map = [];
                $insReview = $pdo->prepare('INSERT INTO reviews (market_slug,title,body,rating,visited_on,created_at,updated_at) VALUES (?,?,?,?,?,?,?)');
                foreach ($manifest['reviews'] as $r) {
                    $insReview->execute([(string)$r['market_slug'], (string)$r['title'], (string)$r['body'], (int)$r['rating'], $r['visited_on'] ?: null, (string)($r['created_at'] ?? gmdate('c')), (string)($r['updated_at'] ?? gmdate('c'))]);
                    $map[(int)$r['id']] = (int)$pdo->lastInsertId();
                }
                $insPhoto = $pdo->prepare('INSERT INTO photos (review_id,filename,mime,created_at) VALUES (?,?,?,?)');
                foreach ($preparedPhotos as $p) $insPhoto->execute([$map[$p['review_id']], $p['filename'], $p['mime'], $p['created_at']]);
                $pdo->commit();
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                throw $e;
            }
            foreach ($oldFiles as $oldFile) @unlink(STORAGE_DIR . '/photos/' . $oldFile);
        } catch (Throwable $e) {
            foreach ($newFiles as $f) @unlink(STORAGE_DIR . '/photos/' . $f);
            throw $e;
        }
    } finally {
        $zip->close();
    }
    flash('success', 'Backupen har återställts! Recensioner och bilder är tillbaka.');
} catch (Throwable $e) {
    flash('error', 'Backup: ' . $e->getMessage());
}
go('admin.php');
